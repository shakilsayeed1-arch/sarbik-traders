# Sarbik Traders — Android Studio প্রজেক্ট (প্রাথমিক সংস্করণ)

এই ZIP-এ একটি প্রাথমিক Kotlin + Jetpack Compose Android অ্যাপের সোর্স কোড দেওয়া হয়েছে।

## এখন যা আছে
- বাংলা ইনভয়েস এন্ট্রি স্ক্রিন
- একই তারিখে একাধিক ইনভয়েসের জন্য আলাদা ইনভয়েস নম্বর
- প্রতি ইনভয়েসে ৩০০০ ইট বা তার অংশবিশেষে গাড়ি ভাড়া: `ceil(পরিমাণ / 3000) × ভাড়ার হার`
- বিক্রির মোট, বাকি, গাড়ি ভাড়া ও নিট প্রাপ্তির প্রিভিউ
- Firebase Firestore-এ ইনভয়েস পাঠানোর প্রাথমিক সংযোগ (Anonymous Authentication)

## APK বানানোর জন্য যা লাগবে
1. কম্পিউটারে Android Studio ইনস্টল করুন।
2. Android Studio-তে এই প্রজেক্টের ফোল্ডার Open করুন।
3. Firebase Console-এ একটি project তৈরি করে Android app যোগ করুন।
4. Package name দিন: `com.sarbiktraders.app`
5. Firebase Authentication-এ Anonymous sign-in চালু করুন।
6. Cloud Firestore তৈরি করুন।
7. Firebase থেকে `google-services.json` ডাউনলোড করে `app/` ফোল্ডারে রাখুন।
8. Android Studio-তে Gradle Sync করুন এবং Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।

## গুরুত্বপূর্ণ সীমাবদ্ধতা
এটি সম্পূর্ণ উৎপাদন-প্রস্তুত অ্যাপ নয়, বরং কাজ শুরু করার সোর্স প্রোটোটাইপ। বর্তমানে ইনভয়েস তালিকা অ্যাপ চালু থাকা সেশনে থাকে; স্থায়ী Room database/offline-first sync, ক্লাউড থেকে ডেটা পুনরুদ্ধার, নিরাপদ ব্যবহারকারী লগইন, ৯ মাসের মাসিক রিপোর্ট, CSV/Excel/PDF export, সম্পাদনা/মুছে ফেলা, ব্যাকআপ নীতি এবং Firestore Security Rules যোগ করা প্রয়োজন। Firebase কনফিগারেশন ছাড়া ক্লাউড সংরক্ষণ কাজ করবে না।

## হিসাবের সংজ্ঞা
- বিক্রির মোট = প্রতি ১০০০ ইটের দাম × ইটের পরিমাণ ÷ ১০০০
- গাড়ি ভাড়া = `ceil(প্রতি ইনভয়েসের ইটের পরিমাণ ÷ ৩০০০) × প্রতি-৩০০০-ইটের ভাড়া`
- বাকি = বিক্রির মোট − ক্যাশ − ব্যাংক (সর্বনিম্ন শূন্য)
- নিট প্রাপ্তি = ক্যাশ + ব্যাংক − গাড়ি ভাড়া − অন্যান্য খরচ

বাস্তব ব্যবহারের আগে হিসাবের নীতি, একাধিক ডিভাইসের ব্যবহার, অ্যাকাউন্ট/লগইন এবং ক্লাউড নিরাপত্তা পরীক্ষা করে নিতে হবে।


## কম্পিউটার ছাড়াই মোবাইল থেকে APK তৈরি (GitHub Actions)
1. Chrome-এ https://github.com খুলে বিনামূল্যে অ্যাকাউন্ট খুলুন/লগইন করুন।
2. `New repository` দিয়ে `sarbik-traders` নামে Public repository তৈরি করুন।
3. ZIP ফাইলটি ফোনে Extract করুন (Files অ্যাপ দিয়ে), তারপর repository-তে `Add file` → `Upload files` দিয়ে ফোল্ডারের সব ফাইল ও `.github` ফোল্ডারসহ আপলোড করে Commit করুন। ZIP সরাসরি repository-তে আপলোড করবেন না; আগে Extract করতে হবে।
4. Repository-র `Actions` ট্যাবে গিয়ে `Build Sarbik Traders APK` workflow খুলুন, `Run workflow` চাপুন।
5. Build শেষ হলে workflow run-এর নিচে `Artifacts` থেকে `Sarbik-Traders-debug-apk` ডাউনলোড করুন। ZIP খুলে `app-debug.apk` ইনস্টল করুন।
6. ফোনে APK ইনস্টল করতে Android Settings-এ Chrome/Files-এর জন্য “Install unknown apps” অনুমতি দিতে হতে পারে।

### গুরুত্বপূর্ণ
- এই workflow প্রাথমিক **debug APK** তৈরি করে; Play Store release-signed APK নয়।
- এই build-এ ইনভয়েস এন্ট্রি/হিসাবের প্রিভিউ ও চলমান সেশনের তালিকা আছে। অ্যাপ বন্ধ করলে ডেটা স্থায়ীভাবে সংরক্ষিত থাকে না।
- Firebase config না থাকায় এই build-এ ক্লাউড সিঙ্ক চালু নয়। ক্লাউড চালু করতে Firebase project, `google-services.json`, login/security rules এবং persistent local database যুক্ত করতে হবে।
- GitHub-এ Public repository করলে সোর্স কোড সবার দেখা যাবে। ব্যক্তিগত রাখতে Private repository বেছে নিতে পারেন; তবে private repository-তে Actions ব্যবহারের সীমা/নীতিমালা প্রযোজ্য।
