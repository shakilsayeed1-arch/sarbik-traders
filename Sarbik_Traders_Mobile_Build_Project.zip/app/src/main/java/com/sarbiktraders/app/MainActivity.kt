package com.sarbiktraders.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.ceil

data class Invoice(
    val date: String = "",
    val invoiceNo: String = "",
    val customer: String = "",
    val brickRatePerThousand: Double = 0.0,
    val quantity: Int = 0,
    val cash: Double = 0.0,
    val bank: Double = 0.0,
    val truckFarePer3000: Double = 0.0,
    val otherCost: Double = 0.0
) {
    val sales: Double get() = brickRatePerThousand * quantity / 1000.0
    val truckFare: Double get() = ceil(quantity / 3000.0) * truckFarePer3000
    val balance: Double get() = (sales - cash - bank).coerceAtLeast(0.0)
    val netReceipt: Double get() = cash + bank - truckFare - otherCost
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FirebaseApp.initializeApp(this)
        setContent { MaterialTheme { SarbikApp() } }
    }
}

@Composable
fun SarbikApp() {
    var date by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())) }
    var invoiceNo by remember { mutableStateOf("") }
    var customer by remember { mutableStateOf("") }
    var rate by remember { mutableStateOf("") }
    var qty by remember { mutableStateOf("") }
    var cash by remember { mutableStateOf("0") }
    var bank by remember { mutableStateOf("0") }
    var fareRate by remember { mutableStateOf("0") }
    var other by remember { mutableStateOf("0") }
    var status by remember { mutableStateOf("প্রতিটি ইনভয়েস আলাদা সারিতে সংরক্ষণ হবে।") }
    var invoices by remember { mutableStateOf(listOf<Invoice>()) }

    val current = Invoice(
        date = date, invoiceNo = invoiceNo, customer = customer,
        brickRatePerThousand = rate.toDoubleOrNull() ?: 0.0,
        quantity = qty.toIntOrNull() ?: 0,
        cash = cash.toDoubleOrNull() ?: 0.0,
        bank = bank.toDoubleOrNull() ?: 0.0,
        truckFarePer3000 = fareRate.toDoubleOrNull() ?: 0.0,
        otherCost = other.toDoubleOrNull() ?: 0.0
    )

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("Sarbik Traders", style = MaterialTheme.typography.headlineMedium)
        Text("ইট বিক্রির হিসাব", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(date, { date = it }, label = { Text("তারিখ (YYYY-MM-DD)") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(invoiceNo, { invoiceNo = it }, label = { Text("ইনভয়েস নম্বর") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(customer, { customer = it }, label = { Text("ক্রেতার নাম") }, modifier = Modifier.fillMaxWidth())
        NumberField("ইটের দাম (প্রতি ১০০০)", rate) { rate = it }
        NumberField("ইটের পরিমাণ", qty, true) { qty = it }
        NumberField("ক্যাশ", cash) { cash = it }
        NumberField("ব্যাংক", bank) { bank = it }
        NumberField("প্রতি ৩০০০ ইটের গাড়ি ভাড়া", fareRate) { fareRate = it }
        NumberField("অন্যান্য খরচ", other) { other = it }

        Card(Modifier.fillMaxWidth().padding(vertical = 10.dp)) {
            Column(Modifier.padding(12.dp)) {
                Text("হিসাবের প্রিভিউ", style = MaterialTheme.typography.titleMedium)
                Text("বিক্রির মোট: ৳${"%.2f".format(current.sales)}")
                Text("গাড়ি ভাড়া: ৳${"%.2f".format(current.truckFare)}")
                Text("বাকি: ৳${"%.2f".format(current.balance)}")
                Text("নিট প্রাপ্তি (ক্যাশ + ব্যাংক - খরচ): ৳${"%.2f".format(current.netReceipt)}")
                Text("গাড়ি ভাড়া = প্রতি ইনভয়েসে ৩০০০ ইট বা তার অংশবিশেষ")
            }
        }
        Button(
            onClick = {
                if (invoiceNo.isBlank() || qty.toIntOrNull() == null || rate.toDoubleOrNull() == null) {
                    status = "ইনভয়েস নম্বর, ইটের দাম ও সঠিক পরিমাণ দিন।"
                } else {
                    invoices = invoices + current
                    status = "ইনভয়েস যোগ হয়েছে (এই প্রোটোটাইপে শুধু সেশনে)। ক্লাউড চালু করতে Firebase সেটআপ প্রয়োজন।"
                    invoiceNo = ""; customer = ""; qty = ""; cash = "0"; bank = "0"; other = "0"
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("ইনভয়েস সংরক্ষণ") }
        Spacer(Modifier.height(8.dp))
        Text(status)
        Spacer(Modifier.height(16.dp))
        Text("এই সেশনের ইনভয়েস: ${invoices.size}", style = MaterialTheme.typography.titleMedium)
        invoices.forEach { inv ->
            ListItem(
                headlineContent = { Text("${inv.invoiceNo} • ${inv.date}") },
                supportingContent = { Text("${inv.customer} | ${inv.quantity} ইট | বিক্রি ৳${"%.0f".format(inv.sales)} | ভাড়া ৳${"%.0f".format(inv.truckFare)}") }
            )
            HorizontalDivider()
        }
        Spacer(Modifier.height(20.dp))
        Text("নোট: এটি প্রাথমিক অ্যাপ প্রোটোটাইপ। স্থায়ী অফলাইন ডেটাবেস, ক্লাউড সিঙ্ক, লগইন, রিপোর্ট ও Excel/PDF এক্সপোর্ট পরবর্তী ধাপে সম্পূর্ণ করতে হবে।")
    }
}

@Composable
fun NumberField(label: String, value: String, integer: Boolean = false, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) },
        keyboardOptions = KeyboardOptions(keyboardType = if (integer) KeyboardType.Number else KeyboardType.Decimal),
        modifier = Modifier.fillMaxWidth()
    )
}

fun saveToCloud(invoice: Invoice, callback: (String) -> Unit) {
    val auth = FirebaseAuth.getInstance()
    val db = FirebaseFirestore.getInstance()
    fun write() {
        val uid = auth.currentUser?.uid ?: return
        val data = hashMapOf(
            "date" to invoice.date, "invoiceNo" to invoice.invoiceNo, "customer" to invoice.customer,
            "brickRatePerThousand" to invoice.brickRatePerThousand, "quantity" to invoice.quantity,
            "sales" to invoice.sales, "cash" to invoice.cash, "bank" to invoice.bank,
            "balance" to invoice.balance, "truckFare" to invoice.truckFare,
            "otherCost" to invoice.otherCost, "netReceipt" to invoice.netReceipt
        )
        db.collection("users").document(uid).collection("invoices").document(invoice.invoiceNo)
            .set(data)
            .addOnSuccessListener { callback("ক্লাউডে সংরক্ষিত হয়েছে।") }
            .addOnFailureListener { callback("ক্লাউড সংরক্ষণ হয়নি: ${it.localizedMessage}") }
    }
    if (auth.currentUser != null) write()
    else auth.signInAnonymously()
        .addOnSuccessListener { write() }
        .addOnFailureListener { callback("Firebase সংযোগ হয়নি: ${it.localizedMessage}") }
}
